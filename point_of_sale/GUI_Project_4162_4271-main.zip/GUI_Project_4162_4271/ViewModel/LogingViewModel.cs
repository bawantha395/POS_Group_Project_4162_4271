﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUI_Project_4162_4271.ViewModel
{
    public class LogingViewModel
    {
        public LogingViewModel() 
        { 
        }
    }
}

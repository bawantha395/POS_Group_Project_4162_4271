﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUI_Project_4162_4271.Model
{
    public class NormalUser
    {

        public string NormalUsername { get; set; }
        public int NormalUserPassword { get; set; }
        public int NormalUserId { get; set; }
        public UserType UserType { get; set; }
    }
    
}
